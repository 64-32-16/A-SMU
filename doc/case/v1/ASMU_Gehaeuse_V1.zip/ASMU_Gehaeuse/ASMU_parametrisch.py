"""A-SMU enclosure V1, mm. Parametric source; needs CadQuery 2.7.

Edit parameter.json, then run this script in an existing CadQuery environment.
No software is needed to open the supplied STEP in SolidCraft's browser app.
Coordinates: X width, Y front-to-back, Z up; front Y=0, bottom Z=0.
"""
from pathlib import Path
from itertools import combinations
import json
import math
import argparse
import cadquery as cq

ROOT = Path(__file__).resolve().parent


def box(x, y, z, dx, dy, dz):
    assert min(dx, dy, dz) > 0
    return cq.Workplane("XY").box(dx, dy, dz, centered=False).translate((x, y, z))


def cylinder(x, y, z, diameter, height):
    return cq.Workplane("XY").center(x, y).circle(diameter / 2).extrude(height).translate((0, 0, z))


def build(p):
    w, h, d, t = (p[k] for k in ["width", "height", "depth", "wall"])
    s, g, ov, c = (p[k] for k in ["split_height", "seam_gap", "overlap", "fit_clearance"])
    pt, ps, gw, gd, ec = (p[k] for k in ["panel_thickness", "panel_setback", "groove_width", "groove_depth", "panel_edge_clearance"])
    rim = t + gd  # Reinforcement makes groove back wall exactly wall thick.
    rl = p["rim_length"]
    tongue = (t - c) / 2
    tongue_x = tongue + c
    assert 0 < s < h
    assert 0 < p["outer_radius"] < t
    assert 0 < c < t and 0 < ec < gd
    assert gw >= pt and ps > (gw-pt)/2
    assert ps + pt + (gw-pt)/2 < rl
    assert s + ov + g < h - rim
    assert w > 2 * rim + 20 and h > 2 * rim + 20 and d > 2 * rl + 40
    assert p["post_offset_y"] - p["post_diameter"]/2 > rl
    assert p["post_offset_x"] - p["post_diameter"]/2 > t
    assert p["insert_bore_diameter"] > p["screw_clearance_diameter"]
    assert p["post_diameter"] > p["driver_access_diameter"] + 2

    bo = box(0, 0, 0, w, d, s).edges("|Y and <Z").fillet(p["outer_radius"])
    bottom = bo.cut(box(t, -1, t, w-2*t, d+2, s+1))
    to = box(0, 0, s+g, w, d, h-s-g).edges("|Y and >Z").fillet(p["outer_radius"])
    top = to.cut(box(t, -1, s-1, w-2*t, d+2, h-t-s+1))

    # Reinforced front/back U rims; all four long exterior corners remain rounded.
    for y in (0, d-rl):
        br = box(0, y, 0, w, rl, s).cut(box(rim, y-1, rim, w-2*rim, rl+2, s+1))
        tr = box(0, y, s+g, w, rl, h-s-g).cut(box(rim, y-1, s-1, w-2*rim, rl+2, h-rim-s+1))
        bottom = bottom.union(br.intersect(bo))
        top = top.union(tr.intersect(to))

    # Two longitudinal stepped laps. Tongue belongs to bottom, sleeve to lid.
    for x in (tongue_x, w-t):
        bottom = bottom.union(box(x, 0, s, tongue, d, ov))
    # Deep enough at reinforced rims to leave assembly clearance there too.
    for x in (tongue, w-t-c):
        top = top.cut(box(x, -1, s-0.01, t+c-tongue, d+2, ov+g+0.01))

    # Grooves at front and back: 0.2 mm on each plate face at defaults.
    slot_front = ps - (gw-pt)/2
    slot_rear = d-ps-pt - (gw-pt)/2
    for y in (slot_front, slot_rear):
        slot = box(t, y, t, w-2*t, gw, h-2*t)
        bottom = bottom.cut(slot)
        top = top.cut(slot)

    # Internal vertical screw guides. Screw heads rest 6 mm below split;
    # a long driver reaches them through the bottom. Standard M3x16 screws.
    seat = s-p["screw_seat_below_split"]
    rb = p["rib_width"]
    for x in (p["post_offset_x"], w-p["post_offset_x"]):
        for y in (p["post_offset_y"], d-p["post_offset_y"]):
            bottom = bottom.union(cylinder(x,y,t,p["post_diameter"],s-t))
            top = top.union(cylinder(x,y,s+g,p["post_diameter"],h-t-s-g))
            rx = t if x < w/2 else x
            rw = x-t if x < w/2 else w-t-x
            bottom = bottom.union(box(rx,y-rb/2,t,rw,rb,s-t))
            top = top.union(box(rx,y-rb/2,s+g,rw,rb,h-t-s-g))
            bottom = bottom.cut(cylinder(x,y,-1,p["driver_access_diameter"],seat+1))
            bottom = bottom.cut(cylinder(x,y,seat,p["screw_clearance_diameter"],s-seat+1))
            top = top.cut(cylinder(x,y,s+g-0.01,p["insert_bore_diameter"],p["insert_length"]+0.01))
            top = top.cut(cylinder(x,y,s+g+p["insert_length"]-0.01,p["screw_clearance_diameter"],p["tip_relief_length"]+0.01))
    # Remove lap relief again where newly-added rib roots meet sleeve.
    for x in (tongue, w-t-c):
        top = top.cut(box(x, -1, s-0.01, t+c-tongue, d+2, ov+g+0.01))

    px = t+ec
    front = box(px, ps, px, w-2*px, pt, h-2*px)
    rear = box(px, d-ps-pt, px, w-2*px, pt, h-2*px)
    parts = {"Boden": bottom.clean(), "Deckel": top.clean(), "Frontplatte": front, "Rueckplatte": rear}
    return parts


COLORS = {"Boden": (.25,.28,.32), "Deckel": (.25,.28,.32), "Frontplatte": (.79,.80,.81), "Rueckplatte": (.44,.47,.50)}


def assembly(parts, exploded=False):
    a = cq.Assembly(name="A_SMU_Gehaeuse_V1" + ("_Explodiert" if exploded else ""))
    shifts = {"Boden": (0,0,0), "Deckel": (0,0,75), "Frontplatte": (0,-45,0), "Rueckplatte": (0,45,0)}
    for name, wp in parts.items():
        v = shifts[name] if exploded else (0,0,0)
        a.add(wp, name=name, color=cq.Color(*COLORS[name]), loc=cq.Location(cq.Vector(*v)))
    return a


def validate(parts, p, exported_dir=None):
    from OCP.BRepTools import BRepTools
    # STL export leaves cached meshes whose bounding boxes include deflection;
    # remove only the display meshes so dimension checks use exact surfaces.
    for wp in parts.values():
        BRepTools.Clean_s(wp.val().wrapped)
    result = {"unit": "mm", "parts": {}, "intersections_mm3": {}, "assembly_path_checks": []}
    for name, wp in parts.items():
        sh = wp.val()
        solids = sh.Solids()
        assert sh.isValid(), f"Invalid shape {name}"
        assert len(solids) == 1, f"Disconnected part {name}: {len(solids)} solids"
        b = sh.BoundingBox()
        result["parts"][name] = {"valid": True, "solids": len(solids), "volume_mm3": round(sh.Volume(),3), "bounds_mm": [round(b.xlen,4),round(b.ylen,4),round(b.zlen,4)]}
    for (na,a),(nb,b) in combinations(parts.items(),2):
        v = a.val().intersect(b.val()).Volume()
        result["intersections_mm3"][f"{na}/{nb}"] = round(v,8)
        assert v < 1e-4, f"Collision: {na}/{nb}: {v}"
    for dz in [0.15, 1, 4, 8, 12, 40, 80]:
        lid = parts["Deckel"].val().translate((0,0,dz))
        for name in ["Boden","Frontplatte","Rueckplatte"]:
            v = lid.intersect(parts[name].val()).Volume()
            assert v < 1e-4, f"Lid assembly collision at {dz} with {name}"
        result["assembly_path_checks"].append({"lid_lift_mm":dz,"collision":False})
    for name in ["Frontplatte","Rueckplatte"]:
        for dz in [0.15, 1, 10, 70, 135]:
            v = parts[name].val().translate((0,0,dz)).intersect(parts["Boden"].val()).Volume()
            assert v < 1e-4, f"Plate insertion collision: {name}, lift {dz}"
    result["plate_insertion_from_top"] = "checked without lid at 0.15, 1, 10, 70, 135 mm lift"
    comp = cq.Compound.makeCompound([x.val() for x in parts.values()])
    bb = comp.BoundingBox()
    result["assembly_bounds_mm"] = [round(bb.xlen,4),round(bb.ylen,4),round(bb.zlen,4)]
    assert all(abs(a-b)<1e-5 for a,b in zip(result["assembly_bounds_mm"],[p["width"],p["depth"],p["height"]])), result["assembly_bounds_mm"]
    result["panel_dimensions_mm"] = [p["width"]-2*(p["wall"]+p["panel_edge_clearance"]),p["height"]-2*(p["wall"]+p["panel_edge_clearance"]),p["panel_thickness"]]
    result["minimum_groove_back_wall_mm"] = p["wall"]
    result["nominal_lap_clearance_mm"] = p["fit_clearance"]
    result["tongue_thickness_mm"] = (p["wall"]-p["fit_clearance"])/2
    if exported_dir:
        for name in parts:
            imported = cq.importers.importStep(str(exported_dir/f"{name}.step")).val()
            assert imported.isValid() and len(imported.Solids())==1
            assert abs(imported.Volume()-parts[name].val().Volume()) < .01
        imported = cq.importers.importStep(str(exported_dir/"ASMU_Gehaeuse.step")).val()
        assert len(imported.Solids())==4 and imported.isValid()
        result["step_roundtrip"] = "4 part files and assembly reimported; solids valid, part volumes match"
    return result


def export(parts, p, out):
    out.mkdir(parents=True,exist_ok=True)
    for name, wp in parts.items():
        cq.exporters.export(wp, str(out/f"{name}.step"))
        # Put meshes on their intended large printing surface, even though
        # the 300-mm depth requires a larger printer or a subsequent split.
        mesh = wp
        if name == "Deckel":
            mesh = wp.rotate((0,0,0),(1,0,0),180).translate((0,p["depth"],p["height"]))
        elif name in ["Frontplatte","Rueckplatte"]:
            mesh = wp.rotate((0,0,0),(1,0,0),90)
            b=mesh.val().BoundingBox()
            mesh=mesh.translate((-b.xmin,-b.ymin,-b.zmin))
        cq.exporters.export(mesh,str(out/f"{name}.stl"),tolerance=.06,angularTolerance=.1)
    assembly(parts).save(str(out/"ASMU_Gehaeuse.step"))
    assembly(parts,True).save(str(out/"ASMU_Explosionsansicht.step"))
    result=validate(parts,p,out)
    (out/"Pruefprotokoll.json").write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    return result


def preview(parts,p,out):
    """CAD mesh preview with a depth buffer, not generated imagery."""
    import numpy as np
    from PIL import Image, ImageDraw, ImageFont
    background=(243,245,247)
    def render(exploded):
        # Orthographic software z-buffer. No browser or GPU required.
        ww,hh=1100,800
        canvas=np.full((hh,ww,3),background,dtype=np.uint8)
        zbuffer=np.full((hh,ww),-np.inf)
        shifts={"Boden":(0,0,0),"Deckel":(0,0,75),"Frontplatte":(0,-45,0),"Rueckplatte":(0,45,0)}
        target=np.array([120.,150.,100. if exploded else 65.])
        view=np.array([660.,-760.,600.])-target;view/=np.linalg.norm(view)
        right=np.cross([0.,0.,1.],view);right/=np.linalg.norm(right)
        up=np.cross(view,right)
        scale=1.8 if exploded else 2.2
        light=np.array([-.6,-.8,1.]);light/=np.linalg.norm(light)
        for name,wp in parts.items():
            verts,tris=wp.val().tessellate(.1,.15)
            world=np.array([[v.x,v.y,v.z] for v in verts])
            if exploded:world+=np.array(shifts[name])
            rel=world-target
            screen=np.column_stack((ww/2+(rel@right)*scale,hh/2-(rel@up)*scale,rel@view))
            for ids in tris:
                q=screen[np.array(ids)]
                x0=max(0,int(np.floor(q[:,0].min())));x1=min(ww-1,int(np.ceil(q[:,0].max())))
                y0=max(0,int(np.floor(q[:,1].min())));y1=min(hh-1,int(np.ceil(q[:,1].max())))
                if x0>x1 or y0>y1:continue
                den=(q[1,1]-q[2,1])*(q[0,0]-q[2,0])+(q[2,0]-q[1,0])*(q[0,1]-q[2,1])
                if abs(den)<1e-10:continue
                yy,xx=np.mgrid[y0:y1+1,x0:x1+1]
                xx=xx+.5;yy=yy+.5
                a=((q[1,1]-q[2,1])*(xx-q[2,0])+(q[2,0]-q[1,0])*(yy-q[2,1]))/den
                b=((q[2,1]-q[0,1])*(xx-q[2,0])+(q[0,0]-q[2,0])*(yy-q[2,1]))/den
                c=1-a-b
                zz=a*q[0,2]+b*q[1,2]+c*q[2,2]
                old=zbuffer[y0:y1+1,x0:x1+1]
                mask=(a>=-1e-8)&(b>=-1e-8)&(c>=-1e-8)&(zz>old)
                if not mask.any():continue
                tri=world[np.array(ids)]
                n=np.cross(tri[1]-tri[0],tri[2]-tri[0]);length=np.linalg.norm(n)
                shade=.56+.44*abs(n@light)/max(length,1e-12)
                color=np.clip(np.array(COLORS[name])*shade*255,0,255).astype(np.uint8)
                canvas[y0:y1+1,x0:x1+1][mask]=color
                old[mask]=zz[mask]
        return Image.fromarray(canvas)
    img=Image.new("RGB",(2250,1200),"#f3f5f7")
    img.paste(render(False),(15,240));img.paste(render(True),(1135,240))
    draw=ImageDraw.Draw(img)
    font_dir=Path("/usr/share/fonts/truetype/dejavu")
    def font(size,bold=False):
        try:return ImageFont.truetype(str(font_dir/("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")),size)
        except OSError:return ImageFont.load_default()
    draw.text((90,50),"A–SMU  /  GEHÄUSE V1",fill="#18283a",font=font(48,True))
    draw.text((90,132),"240 × 130 × 300 mm  ·  Wand 3 mm  ·  Überlappung 8 mm",fill="#526176",font=font(27))
    draw.text((340,215),"Zusammengebaut",fill="#253244",font=font(30))
    draw.text((1350,215),"Vier Bauteile · Montage von oben",fill="#253244",font=font(30))
    draw.text((90,1050),"Front und Rückwand: 233,6 × 123,6 × 3 mm · 3,4-mm-Nuten in verstärkten Rändern",fill="#526176",font=font(25))
    draw.text((90,1100),"Entwurf ohne Display-, Buchsen- und Lüftungsausschnitte. Schrauben und Elektronik nicht dargestellt.",fill="#526176",font=font(23))
    img.save(out/"ASMU_Vorschau.png")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--params",type=Path,default=ROOT/"parameter.json")
    parser.add_argument("--output",type=Path,default=ROOT/"CAD")
    parser.add_argument("--preview",action="store_true")
    args=parser.parse_args()
    p=json.loads(args.params.read_text(encoding="utf-8"))
    parts=build(p)
    result=export(parts,p,args.output)
    if args.preview: preview(parts,p,args.output)
    print(json.dumps(result,indent=2,ensure_ascii=False))


if __name__=="__main__": main()
