# A-SMU – parametrisches Gehäuse V1

Stand: 26.11.2026. Einheiten: mm.

## Öffnen in SolidCraft Online

1. https://app.solidcraft.io/ aufrufen.
2. Im Menü **File / Datei → Open / Öffnen** die Datei `CAD/ASMU_Gehaeuse.step` auswählen.
3. Die vier Bauteile erscheinen als Baugruppe. Zum Bewegen einzelner importierter
   Teile bei Bedarf am Baugruppen-Komponentenmenü **Placement → Unlock Contents** wählen.
4. Das importierte Modell kann anschließend als SolidCraft-Projekt gespeichert werden.

Zum Öffnen der STEP-Datei in der Onlineversion ist keine lokale CAD-Installation erforderlich.
Der Browser muss WebGL2 oder WebGPU unterstützen. Im Arbeitsbrowser des Erstellers
startete SolidCraft wegen fehlender Grafikunterstützung nicht. Deshalb wurde die
Datei nicht direkt in SolidCraft geöffnet; sie wurde mit dem CAD-Kern geprüft,
exportiert und anschließend erneut eingelesen.

**Formatgrenze:** STEP überträgt Volumenkörper, Baugruppen und Farben, jedoch nicht
die veränderbaren Quellparameter oder eine native SolidCraft-Bearbeitungshistorie.
Dieses Paket ist daher keine native parametrische `.sc`-Datei. Die parametrische
Modellquelle ist `ASMU_parametrisch.py`, ihre Werte stehen in `parameter.json`.
Die JSON-Datei ist eine Parametertabelle, kein SolidCraft-Projekt.
Für eine neue Modellvariante können diese Dateien erneut hier bearbeitet und die
STEP-Dateien neu erzeugt werden; dafür muss auf dem Rechner des Nutzers nichts
installiert werden. Der Quellcode ist zusätzlich für vorhandene CadQuery-2.7-
Umgebungen verwendbar.

Die Importmöglichkeiten und das Verhalten von STEP sind in der offiziellen
Dokumentation beschrieben: https://docs.solidcraft.io/guide/files.html

## Modellaufbau

| Merkmal | Wert |
| --- | --- |
| Außenmaße B × H × T | 240 × 130 × 300 |
| Wandstärke | 3 |
| Außenradius der unteren/oberen Längskanten | 2 |
| Trennhöhe | 65 |
| Sichtbarer Spalt zwischen den Hälften | 0,3 |
| Überlappung | 8 |
| Dicke der inneren Führungszunge | 1,35 |
| Spiel zwischen Zunge und äußerer Deckellippe | 0,3 |
| Front-/Rückplatten B × H × Stärke | 233,6 × 123,6 × 3 |
| Plattennutbreite | 3,4 |
| Nuttiefe gegenüber der verstärkten Innenkontur | 2,5 |
| Plattenkantenspiel zum Nutgrund | 0,2 je Kante |
| Freiraum an den Plattenflächen | 0,2 je Fläche |
| Plattenfront gegenüber äußerer Stirnkante | 2 zurückgesetzt |
| Verstärkter Rand vor/hinter dem Innenraum | 8 lang |
| Materialdicke hinter den Nuten | 3 |

Der Boden ist eine U-Schale. An den beiden Seiten läuft eine innere Führungszunge
nach oben. Der Deckel besitzt dort eine entsprechende äußere Lippe; die
Überlappung bleibt innerhalb der Gehäuseaußenkontur. An den Stirnseiten halten
verstärkte U-Ränder die eingeschobenen Platten. Der Deckel fängt deren Oberkanten.

Die Nuten schneiden nicht 2,5 mm tief in eine nur 3 mm starke ungestützte Wand:
An diesen Stellen ist die Innenkontur verstärkt. Hinter der Nut bleiben 3 mm
Material stehen. Im Bereich der seitlichen Überlappung sind die Deckelränder
freigeschnitten, damit sie nicht mit den Boden-Führungszungen kollidieren.

## Montage und Schrauben

1. Vier passende M3-Gewindeeinsätze von unten in die Deckelaufnahmen setzen.
2. Front und Rückplatte bei offenem Gehäuse von oben in die Bodennuten einschieben.
3. Deckel senkrecht von oben aufsetzen.
4. Von unten mit vier M3-Zylinderkopfschrauben, nominell M3 × 16, sichern.

Die vier Schraubenführungen liegen bei X = 10,5 / 229,5 und Y = 20 / 280.
Die Schraubenköpfe sitzen auf inneren Schultern bei Z = 59. Von der Bodenfläche
führen 6,6-mm-Zugangskanäle zu diesen Schultern; zum Anziehen ist daher ein
schlanker, ausreichend langer Innensechskantschlüssel nötig. Die Schrauben sind
keine 65 mm langen durchgehenden Gehäuseschrauben.

Die Deckelbohrungen sind mit 4,1 mm Durchmesser und 6 mm Länge für Gewindeeinsätze
vorbereitet; dahinter liegt eine 3,4-mm-Freibohrung für die Schraubenspitze.
Bohrungsmaß, Einsatzlänge und Schraubenlänge vor der Fertigung an den tatsächlich
verwendeten Gewindeeinsatz anpassen. Schrauben und Einsätze sind nicht als
zusätzliche Körper modelliert.

## Enthaltene Dateien

- `CAD/ASMU_Gehaeuse.step`: zusammengebaute, farbige Vier-Teil-Baugruppe.
- `CAD/ASMU_Explosionsansicht.step`: dieselben Bauteile auseinandergezogen.
- `CAD/Boden.step`, `Deckel.step`, `Frontplatte.step`, `Rueckplatte.step`: Einzelteile.
- `CAD/*.stl`: Einzelteilnetze auf der jeweils großen vorgesehenen Auflagefläche.
- `CAD/ASMU_Vorschau.png`: geometrisch berechnete Vorschau des tatsächlichen Modells.
- `ASMU_parametrisch.py`, `parameter.json`: reproduzierbare parametrische Quelle.
- `CAD/Pruefprotokoll.json`: Form-, Kollisions-, Montage- und STEP-Rückleseprüfung.
- `CAD/Parameter_Variation_Pruefung.json`: zusätzlicher Neuaufbau mit B=260,
  H=150, T=320, Wand=3,2 und Trennhöhe=75.

## Prüfstand und nächste Konstruktion

Alle vier Bauteile sind jeweils ein gültiger zusammenhängender Volumenkörper.
Die Teile überschneiden sich in Montageposition nicht. Das senkrechte Anheben
des Deckels wurde an mehreren Positionen zwischen 0,15 und 80 mm geprüft;
das Einschieben der Platten bei offenem Deckel ebenfalls. Einzelteil-STEPs und
Gesamtbaugruppe wurden nach dem Export erneut eingelesen; die Körper bleiben
gültig und die Einzelteilvolumina stimmen überein. Die Außenmaße sind
240 × 130 × 300 mm (X × Z × Y).

Dies ist der mechanische Grundentwurf. Display-, Buchsen-, Kühlkörper-, Lüfter-,
Netzanschluss- und Platinenbefestigungen sind noch nicht eingearbeitet. Die
Gehäusehälften bleiben wie gewünscht jeweils ein Teil mit 300 mm Tiefe; eine
zusätzliche Teilung für den vorhandenen Prusa ist nicht enthalten. Die STLs
sind deshalb keine Zusage, dass die großen Schalen auf dessen Bauraum passen.
Steckspiel und Gewindeeinsatzbohrungen sollten zunächst an einem kurzen
Materialmuster mit dem vorgesehenen Druckmaterial geprüft werden.
